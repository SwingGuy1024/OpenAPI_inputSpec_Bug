#parse("RCM File Header.java")
package ${PACKAGE_NAME};
#parse("RCM Class Header.java")
public class ${NAME} {
}
