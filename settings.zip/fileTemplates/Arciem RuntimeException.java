#parse("RCM File Header.java")
package ${PACKAGE_NAME};
#parse("RCM Class Header.java")
public class ${NAME} extends RuntimeException {
	public ${NAME}(String message) { super(message); }
	public ${NAME}(String message, Throwable pWrappedException) { super(message, pWrappedException); } 
}
