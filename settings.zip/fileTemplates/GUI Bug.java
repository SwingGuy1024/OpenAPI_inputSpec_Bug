package ${PACKAGE_NAME};

/*
Synopsis:

Full OS Version:

Additional Configuration Information:

Development Kit or Runtime Version:

Description:

Steps to reproduce:

Expected Result:

Actual Result:

Error Message(s):

Source Code:

Workaround:


*/

import java.awt.BorderLayout;
import javax.swing.*;

@SuppressWarnings({"HardCodedStringLiteral", "MagicNumber"})
public class ${NAME} extends JPanel {
	private static JFrame sMainFrame;

	public static void main(String[] args) {
		makeFrame();
	}

	private static void makeFrame() {
		sMainFrame = new JFrame("${NAME}");
		sMainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		sMainFrame.add(new ${NAME}(), BorderLayout.CENTER);
		sMainFrame.setBounds(10, 10, 600, 325);
		sMainFrame.setVisible(true);
	}

	public ${NAME}() {
		super(new BorderLayout());
	}

}
