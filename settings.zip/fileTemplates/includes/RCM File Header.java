////////////////////////////////////////////////////////////////////////////////
//
// ArciemJava
//
// Copyright (C) Arciem Engineering
//
// http://www.arciem.com
//
// Made available to Arciem Engineering clients under a royalty-free, worldwide,
// non-exclusive, non-transferable license for use in specific software
// projects developed using Arciem Engineering services. No other use is
// permitted without express written authorization.
//
// Arciem Engineering requests, but does not require, that any bug fixes or
// enhancements to ArciemJava be submitted back to us for inclusion in the
// library. All such submissions become the property of Arciem Engineering.
//
////////////////////////////////////////////////////////////////////////////////
