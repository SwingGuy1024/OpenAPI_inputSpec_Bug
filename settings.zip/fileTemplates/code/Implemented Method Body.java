// TODO: Write ${SIMPLE_CLASS_NAME}.${METHOD_NAME}()
throw new AssertionError("${SIMPLE_CLASS_NAME}.${METHOD_NAME}() is not yet implemented");