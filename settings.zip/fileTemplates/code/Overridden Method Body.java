// TODO: Write ${SIMPLE_CLASS_NAME}.${METHOD_NAME}()
$CALL_SUPER;
throw new AssertionError("${SIMPLE_CLASS_NAME}.${METHOD_NAME}() is not yet implemented");