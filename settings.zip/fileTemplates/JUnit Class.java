#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.Matchers.*;

#parse("File Header.java")
public class ${NAME} {
	@Test
	public void test() {
	}
}
