package ${PACKAGE_NAME};

/*
Synopsis:

Description:

Justification:

Expected Behavior:

Actual Behavior:

Source Code:

Workaround:

*/

import java.awt.BorderLayout;
import javax.swing.*;

@SuppressWarnings({"HardCodedStringLiteral", "MagicNumber"})
public class ${Name} extends JPanel {
	private static JFrame sMainFrame;

	public static void main(String[] args) {
		makeFrame();
	}

	private static void makeFrame() {
		sMainFrame = new JFrame("${Name}");
		sMainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		sMainFrame.add(new ${Name}(), BorderLayout.CENTER);
		sMainFrame.setBounds(10, 10, 600, 325);
		sMainFrame.setVisible(true);
	}

	public ${Name}() {
		super(new BorderLayout());
	}

}
