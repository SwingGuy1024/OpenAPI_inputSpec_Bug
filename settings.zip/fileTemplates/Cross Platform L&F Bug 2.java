package ${PACKAGE_NAME};

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.*;
import javax.swing.plaf.metal.*;

/*
Synopsis:

Full OS Version:

Additional Configuration Information:

Development Kit or Runtime Version:

Description:

Steps to reproduce:

Expected Result:

Actual Result:

Error Message(s):

Source Code:

Workaround:

*/

public class ${NAME} extends JPanel {
	private static LF chosenLf = LF.Platform;
	private ${NAME}() {
		super(new GridLayout(1, 0));
	}

	public static void main(String[] args) {
		showFrame("${NAME}");
	}

	private static JFrame frame;

	private static JFrame createFrame(String name) {
		JFrame localFrame = new JFrame(name);
		JPanel lfPanel = new JPanel(new BorderLayout());
		JPanel lfGrid = new JPanel(new GridLayout(0, 1, 5, 5));
		for (final LF lf: LF.values()) {
			JButton btn = new JButton(lf.toString());
			btn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					chosenLf = lf;
					frame.dispose();
					showFrame(frame.getTitle());
				}
			});
			lfGrid.add(btn);
			if (lf == chosenLf) {
				btn.setText("\u2022 " + btn.getText());
			}
		}
		lfGrid.add(new JLabel(String.format(" Java %s", System.getProperty("java.version")))); // space for extra button, because Motif expands the window too much.
		lfPanel.add(lfGrid, BorderLayout.PAGE_START);
		localFrame.add(lfPanel, BorderLayout.LINE_START);
		localFrame.add(new ${NAME}(), BorderLayout.CENTER);
		if (frame == null) {
			localFrame.pack();
		} else {
			localFrame.setBounds(frame.getBounds());
		}
		return localFrame;
	}

	private static void showFrame(String title) {
		chosenLf.setLf();
		frame = createFrame(title);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setVisible(true);
	}

	private enum LF {
		Platform(UIManager.getSystemLookAndFeelClassName()),
		Metal("javax.swing.plaf.metal.MetalLookAndFeel", new DefaultMetalTheme()),
		Ocean("javax.swing.plaf.metal.MetalLookAndFeel", new OceanTheme()),
		Motif("com.sun.java.swing.plaf.motif.MotifLookAndFeel"),
		CrossPlatform(UIManager.getCrossPlatformLookAndFeelClassName()),
		Nimbus("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel"),
		;
		private final String name;
		private final MetalTheme theme;
		LF(String s) {
			this(s, null);
		}
		LF(String s, MetalTheme theme) {
			this.name=s;
			this.theme = theme;
		}
		public void setLf() {
			if (theme != null) {
				MetalLookAndFeel.setCurrentTheme(theme);
			} else {
				if (name.contains("Metal")) {
					MetalLookAndFeel.setCurrentTheme(new OceanTheme());
				}
			}
			try {
				UIManager.setLookAndFeel(name);
			} catch (Exception ignored) { }
		}
	}
}
