package ${PACKAGE_NAME};

/*
Synopsis:

Full OS Version:

Additional Configuration Information:

Development Kit or Runtime Version:

Description:

Steps to reproduce:

Expected Result:

Actual Result:

Error Message(s):

Source Code:

Workaround:

*/

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import javax.swing.*;
import javax.swing.plaf.metal.OceanTheme;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.plaf.metal.DefaultMetalTheme;
import com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel;

public class ${Name} extends JPanel {
	private static JFrame sMainFrame;

	public static void main(String[] args) {
		makeFrame(LandF.Platform);
	}

	private static void makeFrame(LandF landf) {
		Rectangle oldBounds = null;
		if (sMainFrame != null) {
			oldBounds = sMainFrame.getBounds();
			sMainFrame.dispose();
		}
		landf.install();
		sMainFrame = new JFrame("${Name}");
		sMainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		sMainFrame.add(new ${Name}(), BorderLayout.CENTER);
		sMainFrame.add(makeLandFButtons(), BorderLayout.WEST);
		if (oldBounds == null)
			sMainFrame.setBounds(10, 10, 600, 325);
		else
			sMainFrame.setBounds(oldBounds);
		sMainFrame.setVisible(true);
	}

	public ${Name}() {
		super(new BorderLayout());
	}

	private static JPanel makeLandFButtons() {
		JPanel pnl = new JPanel(new GridLayout(0, 1));
		LandF[] all = LandF.values();
		for (LandF lf : all)
			pnl.add(new JButton(lf.getAction()));
		pnl.add(new JLabel(System.getProperty("java.version"))); // NON-NLS
		JPanel outerPanel = new JPanel();
		outerPanel.add(pnl);
		return outerPanel;
	}

	private enum LandF {
		Platform(UIManager.getSystemLookAndFeelClassName()),
		Metal(MetalLookAndFeel.class.getName()),
		Ocean(UIManager.getCrossPlatformLookAndFeelClassName()),
		Motif(com.sun.java.swing.plaf.motif.MotifLookAndFeel.class.getName()),
		Nimbus(NimbusLookAndFeel.class.getName()),
		;
		final private String mName;
		private Action mAction;

		LandF(String name) {
			mName = name;
			mAction = new LandFAction(this);
		}

		public String getLFName() { return mName; }

		public void install() {
			//noinspection CatchGenericClass
			try {
				UIManager.setLookAndFeel(getLFName());
				extra();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public Action getAction() {
			return mAction;
		}

		private void extra() throws UnsupportedLookAndFeelException {
			if (this == Metal) {
				MetalLookAndFeel lf = (MetalLookAndFeel) UIManager.getLookAndFeel();
				lf.setCurrentTheme(new DefaultMetalTheme());
				UIManager.setLookAndFeel(lf); // set it again
			} else if (this == Ocean) {
				MetalLookAndFeel lf = (MetalLookAndFeel) UIManager.getLookAndFeel();
				lf.setCurrentTheme(new OceanTheme());
				UIManager.setLookAndFeel(lf); // set it again
			}
		}
	}

	private static class LandFAction extends AbstractAction {
		private LandF mLookAndFeel;

		public void actionPerformed(ActionEvent e) { makeFrame(mLookAndFeel); }

		LandFAction(LandF lAndF) {
			super(lAndF.toString());
			mLookAndFeel = lAndF;
		}
	}
}
